package com.OpenMal.vulnrouterscan;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.text.Html;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class MainActivity extends AppCompatActivity {
    static String SHA1Encrypt(String InputString) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] messageDigest = md.digest(InputString.getBytes());
            BigInteger no = new BigInteger(1, messageDigest);
            String hashtext = no.toString(16);
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            // return the HashText
            return hashtext;
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public static class Consts {
        public static String ROP = "Placeholder lmao";
        public static boolean alreadyExecuted = false;
        public static boolean output = false;
        public static boolean ReturnedValid = false;
    }

    final String PREFS_NAME = "MyPrefsFile";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Load the main GUI
        TextView textView =(TextView)findViewById(R.id.textView4);
        textView.setClickable(true);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        String text = "<a href='https://github.com/GhostDog98/VulnerableRouterScanner'>Github Page</a>";
        textView.setText(Html.fromHtml(text, Html.FROM_HTML_MODE_COMPACT));

        textView = findViewById(R.id.Title);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 23);

        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);

        if (settings.getBoolean("my_first_time", true)) {
            //the app is being launched for first time, do something
            Log.d("Comments", "First time");

            // first time task
            String fileName = "RouterPageHashesPassW.txt";
            String textToWrite = "cfa8c429592d340f97b76b4fd36cc8617254bfd9, Sagemcom Optus Family F@ST, optus, Network Password\n";
            FileOutputStream outputStream;

            try {
                Log.d("error", "Got to line 95");
                outputStream = openFileOutput(fileName , Context.MODE_PRIVATE);
                outputStream.write(textToWrite.getBytes());
                outputStream.close();

            } catch (Exception e) {
                Log.d("error", "Error line 99");
                e.printStackTrace();
            }
            // record the fact that the app has been started at least once
            settings.edit().putBoolean("my_first_time", false).commit();
        }else{
            Log.d("Comments", "not first time");
        }








    }

    boolean CheckIfExists(String InputURL){
        if(!Consts.alreadyExecuted){ // Only ever do this once
            final RequestQueue queue = Volley.newRequestQueue(this);
            Consts.alreadyExecuted = true;

        final String url = InputURL;
        final StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        TextView t = (TextView) findViewById(R.id.textView2);

                        t.setText(" " + url);
                        Consts.ROP = response;
                        Log.d("onResponse1", Consts.ROP);
                        Consts.ReturnedValid = true;

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Consts.ReturnedValid = false;
            }
    });
        queue.add(stringRequest);
        return Consts.ReturnedValid;
        }else{ //-----------------------------------------------------------------------------------
            // If this has been executed before, then no need to even worry about initializing the queue
            final RequestQueue queue = Volley.newRequestQueue(this);


            final String url = InputURL;
            final StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            TextView t = (TextView) findViewById(R.id.textView2);

                            t.setText(" " + url);
                            Consts.ROP = response;
                            Log.d("onResponse1", Consts.ROP);
                            Consts.ReturnedValid = true;


                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Consts.ReturnedValid = false;
                }
            });
            queue.add(stringRequest);
            return Consts.ReturnedValid;
        }
    }



    @SuppressLint("SetTextI18n")
    public void But1Press(View view) { // "Check 4 vulnerable" button
        String[] URLsToCheck = {
                "http://192.168.0.1/",
                "http://10.0.0.1",
                "http://192.168.1.1",
                "http://192.168.1.254",
                "http://10.0.0.138",
                "http://192.168.1.10.1",
                "http://192.168.254.254",
                "http://192.168.2.1",
                "http://10.0.1.1",
                "http://192.168.0.30",
                "http://192.168.0.50"};
        try {
            for (int i = 0; i < URLsToCheck.length; i++) {
                CheckIfExists(URLsToCheck[i]);
                Log.d("Checking URL: ", URLsToCheck[i]);
            }

            Log.d("Done Notice", "Done with checking");
        }catch(Exception RuntimeException){
            Log.d("Error: ", String.valueOf(RuntimeException));
        }
    }



    @SuppressLint("SetTextI18n")
    public void But2Press(View view) throws IOException { // Query database button


        TextView t = (TextView) findViewById(R.id.textView2);
        CharSequence domain = t.getText();
        Log.d("main1", Consts.ROP);
        String PageHash = SHA1Encrypt(Consts.ROP);
        TextView tv3 = findViewById(R.id.RouterName); // Login details status, WRITE TO
        TextView tv4 = findViewById(R.id.Uname); // Username, WRITE TO
        TextView tv5 = findViewById(R.id.PassW); // Password, WRITE TO
        String fileName = "/data/data/com.OpenMal.vulnrouterscan/files/RouterPageHashesPassW.txt";

        FileReader file = new FileReader(fileName);
        BufferedReader buffer = new BufferedReader(file);
        String line;
        line = buffer.readLine();
        if(line != null){
            String Temp1 = line;
            // If the line matches the login details
            if(line.contains(PageHash)){
                tv3.setText("RouterName: " + line.split(", ")[1]);
                tv4.setText("Username: " + line.split(", ")[2]);
                tv5.setText("Password: " + line.split(", ")[3]);
            }
        }else{
            tv3.setText("NOT FOUND");
        }












        // Directory of routers!
        //List<String> FAST_3864V3HP = readAllLines(Paths.get("app/ExamplePages/FAST_3864V3HP.txt"));
        //List <String> test =


        String temp1;

    }

    class InvalidNewEntry extends Exception { // New Exception! This is thrown when the user doesnt supply valid entries for the new creation tool
        InvalidNewEntry(String s) {
            super(s);
        }
    }


        public void But3Press(View view) throws InvalidNewEntry, IOException { // Add new entry
            EditText ED_Name = (EditText) findViewById(R.id.ET_Router_Name);
            EditText ED_UserN = (EditText) findViewById(R.id.ET_Router_Username);
            EditText ED_PassW = (EditText) findViewById(R.id.ET_Router_Password);
            String ED_Name_Str = ED_Name.getText().toString();
            String ED_UserN_Str = ED_UserN.getText().toString();
            String ED_PassW_Str = ED_PassW.getText().toString();
            if (TextUtils.isEmpty(ED_Name.getText())) {
                // Complain
                throw new InvalidNewEntry("Invalid Name for ED_Name");
            } else if (TextUtils.isEmpty(ED_UserN.getText())) {
                throw new InvalidNewEntry("Invalid Username for ED_UserN");
            } else if (TextUtils.isEmpty(ED_Name.getText())) {
                throw new InvalidNewEntry("Invalid Password for ED_PassW");
            } else { // If we reach here we are all good!
                String PageHash = SHA1Encrypt(Consts.ROP);
                String WriteAbleEntry = PageHash + "," + ED_Name_Str + "," + ED_UserN_Str + "," + ED_PassW_Str + "\n";
                FileOutputStream fOut = openFileOutput("RouterPageHashesPassW.txt", MODE_APPEND);
                OutputStreamWriter osw = new OutputStreamWriter(fOut);
                osw.write(WriteAbleEntry);
                osw.flush();
                osw.close();
                ED_Name.getText().clear();
                ED_UserN.getText().clear();
                ED_PassW.getText().clear();

            }
        }


        }




